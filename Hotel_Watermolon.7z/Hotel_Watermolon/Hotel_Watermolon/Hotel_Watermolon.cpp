// Hotel_Watermolon.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include"stdafx.h"
#include <iostream>
#include <cstdlib>
#include <conio.h>
#include <string>
#include <fstream>
using namespace std;

class Wirtual
{
public:
	virtual void wyswietl() = 0;
};

class Hotel :virtual public Wirtual {
protected:
	int pokoje;
	friend void wyswietl(Hotel & Ho);
	friend class Globalna;

	class Klient {
	private:
		string imie;
		string nazwisko;
		int pesel;
		int numer_telefonu;
		int id;
	public:
		Klient();
		void dodaj_klienta();
		void set_klienta(string, string, int, int);
		void wyswietl();
		void set_imie(string i) { imie = i; }
		void set_nazwisko(string n) { nazwisko = n; }
		void set_pesel(int r) { pesel = r; }
		void set_numer(int nr) { numer_telefonu = nr; }
		void set_id(int a);
		int get_id();
		string get_imie();
		string get_nazwisko();
		string &GET_NAZWISKO();
		int get_numer_telefonu();
		int get_pesel();
	};
public:
	Klient ** klient;
	Hotel();
	Hotel(const Hotel *hot);
	void dodaj_klienta();
	void wyswietl();
	void wyswietl_klienta(int);
	int get_pokoje();
	void create_klient();
	void delete_klient();
	void ADD();
	void INSERT(int);
	void REMOVE(int);
	void dodaj_(int);
	void wczytaj();
	Hotel *operator()(int liczba);
	string &operator[](int index);
	Hotel *operator=(Hotel *x);

};
class Pokoj :virtual public Wirtual {
protected:
	const int stala;
	int numer_pokoju;

public:
	Pokoj();
	void set_numer(int);
	int get_numer();
	void wyswietl();
	friend istream &operator>>(istream &wejscie, Pokoj *pok);
	Pokoj *operator->();
};
class Informacje;
class Globalna {
public:
	static Wirtual **w;
	static Informacje *informacje;
	static void create_wirtual();
	static int ilosc_pokoi, licznik_ludzie, index;
	static char wybor;
	static Hotel *ho;
	static Pokoj *pok;
	static void create_();
	static void create_hotel();
	static void create_pokoj();
	static void menu();
	static void delete_Hotel();
	static void delete_pokoj();
	static void delete_all();
	static int walidacja_wejscia_INT();
	static string walidacja_wejscia_STRING();
	friend ostream &operator<<(ostream &wyjscie, Pokoj *pok);
	friend istream &operator>>(istream &wejscie, Pokoj *pok);
};

class Informacje :public Hotel, public Pokoj, public Globalna
{
public:
	Informacje() :Hotel() {};
	virtual void wyswietl();
};



/*
zmienne globalne test
*/
Wirtual** Globalna::w = NULL;
Hotel * Globalna::ho = NULL;
Pokoj * Globalna::pok = NULL;
int Globalna::licznik_ludzie = 0;
int Globalna::ilosc_pokoi = 40;
int Globalna::index = 0;
char Globalna::wybor;
Informacje* Globalna::informacje = new Informacje;
/*
Klient
*/
Hotel::Klient::Klient()
{
	imie = "Brak";
	nazwisko = "Brak";
	pesel = 0;
	numer_telefonu = 0;
}
string Hotel::Klient::get_imie()
{
	return imie;
}
void Hotel::Klient::wyswietl()
{
	cout << "Imie: " << get_imie() << ", Nazwisko: " << this->imie << ", pesel: " << this->pesel << ", Numer telefonu: " << this->numer_telefonu << endl;
}
void Hotel::Klient::set_klienta(string imie, string nazwisko, int pesel, int numer_telefonu)
{
	this->imie = imie;
	this->nazwisko = nazwisko;
	this->pesel = pesel;
	this->numer_telefonu = numer_telefonu;
}
void Hotel::Klient::dodaj_klienta()
{
	string i, n;
	int r, nr;
	fstream PLIK;
	PLIK.open("Hotel.txt", ios::app | std::ios::in | std::ios::out);
	if (PLIK.good() == true)
	{
		PLIK << "\n";
		cout << "Imie: " << endl;
		i = Globalna::walidacja_wejscia_STRING();
		PLIK << i << " ";
		cout << "Nazwisko: " << endl;
		n = Globalna::walidacja_wejscia_STRING();
		PLIK << n << " ";
		cout << "pesel: " << endl;
		r = Globalna::walidacja_wejscia_INT();
		PLIK << r << " ";
		cout << "Numer telefonu: " << endl;
		nr = Globalna::walidacja_wejscia_INT();
		PLIK << nr << " ";
		PLIK << get_id();
		PLIK.close();
		set_klienta(i, n, r, nr);
	}
	else
		cout << "Nie da sie otworzyc pliku!" << endl;
}
void Hotel::Klient::set_id(int a)
{
	id = a;
}
int Hotel::Klient::get_id()
{
	return id;
}
string Hotel::Klient::get_nazwisko()
{
	return nazwisko;
}
int Hotel::Klient::get_numer_telefonu()
{
	return numer_telefonu;
}
int Hotel::Klient::get_pesel()
{
	return pesel;
}
/*
Klasa Hotel
*/
void Hotel::wczytaj()
{
	string i, n;
	int r, nr, nr2;
	fstream PLIK;
	PLIK.open("Hotel.txt", std::ios::in);
	if (PLIK)
	{
		while (!PLIK.eof())
		{
			PLIK >> i >> n >> r >> nr >> nr2;
			if (Globalna::pok[nr2].get_numer() == 77)
			{
				ADD();
				Globalna::pok[nr2].set_numer(nr2);
				Globalna::ho->klient[Globalna::licznik_ludzie - 1]->set_id(nr2);
				Globalna::ho->klient[Globalna::licznik_ludzie - 1]->set_klienta(i, n, r, nr);
			}
		}
	}
	else
		cout << "Nie da sie otworzyc pliku!" << endl;
	PLIK.close();
}

void Hotel::ADD()
{
	Klient **tab1 = new Klient*[Globalna::licznik_ludzie + 1];
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
	{
		tab1[i] = klient[i];
	}
	tab1[Globalna::licznik_ludzie] = new Klient;
	delete[] klient;
	klient = tab1;
	Globalna::licznik_ludzie++;
}
void Hotel::INSERT(int index)
{
	Klient** nowy1 = new Klient*[Globalna::licznik_ludzie + 1];
	for (int i = 0; i<Globalna::licznik_ludzie; i++)
	{
		if (i<index)
		{
			nowy1[i] = klient[i];
		}
		else
		{
			if (i >= index)
			{
				nowy1[i + 1] = klient[i];
			}
		}
	}
	nowy1[index] = new Klient;
	delete[] klient;
	klient = nowy1;
	Globalna::licznik_ludzie++;
}
void Hotel::REMOVE(int index)
{
	Klient **tab1 = new Klient*[Globalna::licznik_ludzie - 1];
	int j = 0;
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
	{
		if (i != index)
		{
			tab1[j] = klient[i];
		}
		else continue;
		j++;
	}
	delete klient[index];
	delete[] klient;
	klient = tab1;
	Globalna::licznik_ludzie--;
}
void Hotel::dodaj_(int licznik)
{
	klient[licznik]->dodaj_klienta();
}
void Hotel::create_klient()
{
	klient = new Klient*[Globalna::licznik_ludzie];
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
	{
		klient[i] = new Klient;
	}
}
void Hotel::delete_klient()
{
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
		delete klient[i];
	delete[] klient;
}
/*
*/
Hotel::Hotel() :pokoje(Globalna::ilosc_pokoi) {}
Hotel::Hotel(const Hotel *hot)
{
	this->pokoje = hot->pokoje;
}
int Hotel::get_pokoje()
{
	return pokoje;
}
string &Hotel::Klient::GET_NAZWISKO()
{
	return nazwisko;
}
/*
Dzialanie na klasie wewnetrznej
*/
void Hotel::wyswietl()
{
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
	{
		klient[i]->wyswietl();
	}

}
void Hotel::wyswietl_klienta(int a)
{
	klient[a]->wyswietl();
}
void Hotel::dodaj_klienta()
{
	klient[Globalna::licznik_ludzie]->dodaj_klienta();
}
Hotel *Hotel::operator()(int liczba)
{
	this->pokoje = liczba;
	return this;
}

string &Hotel::operator[](int index)
{
	return klient[index]->GET_NAZWISKO();
}
Hotel * Hotel::operator=(Hotel *x)
{
	klient = new Klient*[Globalna::licznik_ludzie];
	Klient *NEW, *OLD;
	for (int i = 0; i < Globalna::licznik_ludzie; i++)
	{
		OLD = x->klient[i];
		klient[i] = new Klient;
		NEW = klient[i];
		NEW->set_id(OLD->get_id());
		NEW->set_klienta(OLD->get_imie(), OLD->GET_NAZWISKO(), OLD->get_pesel(), OLD->get_numer_telefonu());
	}
	return this;
}

/*
Pokoj
*/
Pokoj::Pokoj() : stala(5)
{
	numer_pokoju = 77;
}
void Pokoj::set_numer(int a)
{
	numer_pokoju = a;
}
int Pokoj::get_numer()
{
	return numer_pokoju;
}

void Pokoj::wyswietl()
{
	if (Globalna::licznik_ludzie == 0)
	{
		cout << "Wszystkie pokoje sa wolne!";
	}
	else
	{
		cout << "Zajete pokoje: " << endl;
		for (int i = 0; i < Globalna::ilosc_pokoi; i++)
		{
			if (Globalna::pok[i].get_numer() != 77)
				cout << Globalna::pok[i].get_numer() + 1 << ", ";
		}
	}
}
//Operator ->
Pokoj *Pokoj::operator->()
{
	return this;
}
//Globalne
void Globalna::create_()
{
	create_hotel();
	ho->create_klient();
	create_pokoj();
}
void Globalna::create_hotel()
{
	ho = new Hotel;
}
void Globalna::create_pokoj()
{
	pok = new Pokoj[ilosc_pokoi];
}
void Globalna::delete_Hotel()
{
	//    delete ho;
	ho = 0;
}
void Globalna::delete_pokoj()
{
	delete[] pok;
}
void Globalna::delete_all()
{
	delete_pokoj();
	delete_Hotel();
}
/*
INNE
*/
int Globalna::walidacja_wejscia_INT()
{
	int a;
	cin >> a;
	while (cin.fail() == 1) 	//sprawdzanie wejscia
	{
		cout << "Wpisz poprawne dane!" << endl;
		cin.clear();
		cin.sync();
		cin >> a;
	}
	return a;
}
string Globalna::walidacja_wejscia_STRING()
{
	string a;
	cin >> a;
	while (cin.fail() == 1) 	//sprawdzanie wejscia
	{
		cout << "Wpisz poprawne dane!" << endl;
		cin.clear();
		cin.sync();
		cin >> a;
	}
	return a;
}


void Globalna::menu()
{

	//Hotel *aka2;
	create_wirtual();
	string nazwa;
	int nr;
	int nr_pok, y = 99, z;
	while (y)
	{
		if (ho == 0)
		{
			cout << "Pomyslnie usunieto dane." << endl;
			create_pokoj();
			create_hotel();
		}
		cout << "\t\t-Menu-" << endl;
		cout << "1. Dodawawanie do pokoju" << endl;
		cout << "2. Usuwanie klienta z pokoju" << endl;
		cout << "3. Wyswietl liste klient�w" << endl;
		cout << "4. Sprawdz zajete pokoje" << endl;
		cout << "5. Wyswietl klienta danego pokoju" << endl;
		cout << "6. Sprawdz czy klient o podanym numerze ma podane nazwisko" << endl;
		cout << "7. Zmien liczbe pokoi" << endl;
		cout << "8. Zamknij program" << endl;
		z = Globalna::walidacja_wejscia_INT();
		switch (z)
		{
		case 1:
			system("CLS");
			cout << "Do ktorego pokoju chcesz dodac Klienta? [1-" << ho->get_pokoje() << "]" << endl;
			nr_pok = Globalna::walidacja_wejscia_INT();
			if (nr_pok > ho->get_pokoje() || nr_pok < 1)
			{
				cout << "Podaj numer z przedzialu!" << endl;
				break;
			}
			else if (pok[nr_pok - 1]->get_numer() != 77)
			{
				cout << "Pokoj zajety!" << endl;
				break;
			}


			ho->ADD();
			ho->klient[Globalna::licznik_ludzie - 1]->set_id(nr_pok - 1);
			pok[nr_pok - 1]->set_numer(ho->klient[Globalna::licznik_ludzie - 1]->get_id());
			ho->dodaj_(Globalna::licznik_ludzie - 1);
			break;
		case 2:
			system("CLS");
			cout << "Z ktorej pozycji chcesz usunac Klienta? " << endl;
			Globalna::index = Globalna::walidacja_wejscia_INT();
			if (Globalna::index > Globalna::licznik_ludzie || Globalna::index <= 0)
			{
				cout << "Nie ma Klienta na tej pozycji!" << endl;
				break;
			}
			else
				cout << "Czy napewno chcesz usunac Klienta o danych : " << endl;
			ho->wyswietl_klienta(index - 1);
			cout << "z pozycji nr " << Globalna::index << "? [T/N]" << "\nDane: " << endl;
			cin >> Globalna::wybor;
			if (Globalna::wybor == 'T' || Globalna::wybor == 't')
			{
				ho->REMOVE(Globalna::index - 1);
				pok[Globalna::index - 1].set_numer(77);
				cout << "Usunieto Klienta!" << endl;
			}
			else if (wybor == 'N' || wybor == 'n')
			{
				cout << "Zdecydowales sie nikogo nie usuwac." << endl;
				break;
			}
			else cout << "Zla opcja" << endl;

			break;
		case 3:
			system("CLS");
			ho->wyswietl();
			if (Globalna::licznik_ludzie == 0)
				cout << "Nie dodano zadnych mieszkancow!" << endl;
			break;
		case 4:
			system("CLS");
			w[2]->wyswietl();
			cout << endl;
			break;
		case 5:
			system("CLS");
			cout << "Ktory pokoj sprawdzic?" << endl;
			nr_pok = Globalna::walidacja_wejscia_INT();
			for (int i = 0; i < Globalna::licznik_ludzie; i++)
			{
				if (ho->klient[i]->get_id() == Globalna::pok[nr_pok - 1].get_numer())
				{
					cout << "Klient pokoju nr " << nr_pok << " to: " << endl;
					ho->wyswietl_klienta(i);
					break;
				}
			}
			if (Globalna::pok[nr_pok - 1].get_numer() == 77)
				cout << "Pokoj wolny." << endl;
			break;
		case 6: // []
			system("CLS");
			if (licznik_ludzie > 0)
			{
				cout << "Podaj numer Klienta [1-" << licznik_ludzie << "]" << endl;
				nr = walidacja_wejscia_INT();
				while (nr > licznik_ludzie || nr <= 0)
				{
					cout << "Wpisz odpowiednia liczbe z przedzialu! " << endl;
					nr = walidacja_wejscia_INT();
				}
				cout << "Podaj nazwisko do sprawdzenia" << endl;
				nazwa = walidacja_wejscia_STRING();

				if ((*ho)[nr - 1] == nazwa)
				{
					cout << "Tak, Klient o numerze " << nr << " nazywa sie \"" << nazwa << "\"" << endl;
				}
				else  cout << "Nie, Klient o numerze " << nr << " nie nazywa sie \"" << nazwa << "\", tylko \"" << (*ho)[nr - 1] << "\"" << endl;

			}
			else cout << "Nie ma jeszcze mieszkancow w bazie!" << endl;
			break;
		case 7:
			system("CLS");
			cout << "Ile pokoi ma miec hotel?" << endl;
			nr = walidacja_wejscia_INT();
			if (nr <= licznik_ludzie || nr <= 0)
				cout << "Operacja przerwana! Liczba nie moze przekraczac aktualnej liczby mieszkancow ani byc rowna badz mniejsza 0!" << endl;
			else
				(*ho)(nr);
			break;
		case 8:
			y = 0;
			break;

		default:
			cout << "Podaj poprawna opcje!" << endl;
			break;
		}

	}

}
void Globalna::create_wirtual()
{
	w = new Wirtual*[3];
	w[0] = ho;
	w[1] = informacje;
	w[2] = pok;
}
void Informacje::wyswietl()
{
	system("CLS");
	if (licznik_ludzie > 0)
	{
		cout << "Ilosc mieszkancow: " << licznik_ludzie << endl;
		cout << "Ilosc pokoi: " << ilosc_pokoi << endl << endl;

		ho->klient[0]->wyswietl();
	}
	else cout << "Nikogo jeszcze nie wprowadzono!" << endl;
}

int main() {
	Globalna::create_();
	Globalna::menu();
	Globalna::delete_all();
	return 0;
}